#!/usr/bin/env python3
"""Build the eight public Meta template variants."""

from itertools import product
from pathlib import Path
import os
import subprocess


ROOT = Path(__file__).resolve().parent
BUILD = ROOT / "build"
COLORS = ("ustc", "indigo", "wine", "amber")
CITES = ("normalcite", "fancycite")


def run(args: list[str]) -> None:
    subprocess.run(args, cwd=ROOT, check=True, stdout=subprocess.DEVNULL)


def main() -> None:
    BUILD.mkdir(exist_ok=True)
    for color, cite in product(COLORS, CITES):
        cite_name = cite.removesuffix("cite")
        stem = f"meta-{color}-{cite_name}"
        tex = rf"\def\paperoptions{{{color},{cite}}}\input{{main.tex}}"
        pdftex = [
            "pdflatex",
            "-interaction=nonstopmode",
            "-halt-on-error",
            f"-jobname={stem}",
            f"-output-directory={BUILD}",
            tex,
        ]
        run(pdftex)
        bib_env = os.environ | {
            "BIBINPUTS": f"{ROOT}{os.pathsep}",
            "BSTINPUTS": f"{ROOT}{os.pathsep}",
        }
        subprocess.run(
            ["bibtex", stem],
            cwd=BUILD,
            check=True,
            stdout=subprocess.DEVNULL,
            env=bib_env,
        )
        run(pdftex)
        run(pdftex)
        print(BUILD / f"{stem}.pdf")


if __name__ == "__main__":
    main()
