# Pada Meta LaTeX Template

A source-faithful Meta-style paper template with two independent options:

- Color: `ustc`, `indigo`, `wine`, or `amber`
- Citation: `normalcite` or `fancycite`

The title card always uses the single approved Pada treatment: a light horizontal
Logo inside an asymmetric, theme-colored book-page tag at the lower-right corner.
All sans-serif typography uses the standard Helvetica-compatible `helvet` package;
the template contains no bundled proprietary font files.

Choose one color and one citation style:

```tex
\documentclass[indigo,fancycite]{meta}
```

`normalcite` preserves the standard theme-colored author-year citations.
`fancycite` uses a brighter companion color. Each paper color has its own citation
color; the blue edition retains cyan-blue (`#00A7E8`).

Compile `main.tex` with pdfLaTeX and BibTeX, or run:

```sh
python3 build_variants.py
```
