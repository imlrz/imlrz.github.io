# Wenxiaobai Meta LaTeX Template

A source-faithful Meta-style paper template with three independent options:

- Color: `blue`, `purple`, `red`, or `yellow`
- Citation: `normalcite` or `fancycite`
- Logo: `blacklogo` or `colorlogo`

Use any combination in the document class line:

```tex
\documentclass[purple,fancycite,colorlogo]{meta}
```

`normalcite` uses conventional round, near-black author-year citations.
`fancycite` uses accent-colored square citations with a stronger author treatment.
The color logo is an exact text-free crop of the official Wenxiaobai gradient mark.

Compile `main.tex` with pdfLaTeX and BibTeX, or use `latexmk -pdf main.tex`.
