# Wenxiaobai Meta LaTeX Template

A source-faithful Meta-style paper template with three independent options:

- Color: `ustc`, `indigo`, `wine`, or `amber`
- Citation: `normalcite` or `fancycite`
- Logo: `blacklogo` or `colorlogo`

Use any combination in the document class line:

```tex
\documentclass[indigo,fancycite,colorlogo]{meta}
```

`normalcite` uses conventional round, near-black author-year citations.
`fancycite` keeps the same round author-year typography and changes only citation
links to the fluorescent cyan-blue (`#00A7E8`) used by the reference edition.
The color logo is an exact text-free crop of the official Wenxiaobai gradient mark.

Compile `main.tex` with pdfLaTeX and BibTeX, or use `latexmk -pdf main.tex`.
