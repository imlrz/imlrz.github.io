# Wenxiaobai Meta LaTeX Template

A source-faithful Meta-style paper template with three independent options:

- Color: `ustc`, `indigo`, `wine`, or `amber`
- Citation: `normalcite` or `fancycite`
- Logo: `blacklogo` or `colorlogo`

Use any combination in the document class line:

```tex
\documentclass[indigo,fancycite,colorlogo]{meta}
```

`normalcite` preserves the original round, theme-colored author-year citations.
`fancycite` keeps the same page palette and citation structure while using a brighter
companion color. Each paper color has its own companion citation color; the blue
edition retains the reference cyan-blue (`#00A7E8`).
The color logo is an exact text-free crop of the official Wenxiaobai gradient mark.
Every variant also includes the official white Popia wordmark in a compact dark
capsule on the title card. This product mark is fixed rather than optional so
exported papers satisfy the company branding requirement without using the heavier
square app icon.

Compile `main.tex` with pdfLaTeX and BibTeX, or use `latexmk -pdf main.tex`.
