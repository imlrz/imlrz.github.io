# Pada Meta LaTeX Template

A source-faithful Meta-style paper template with three independent options:

- Color: `ustc`, `indigo`, `wine`, or `amber`
- Citation: `normalcite` or `fancycite`
- Logo: `blacklogo` or `colorlogo`

Use any combination in the document class line:

```tex
\documentclass[indigo,fancycite,colorlogo]{meta}
```

`normalcite` preserves the original round, theme-colored author-year citations.
`fancycite` keeps the same page palette and citation structure while using a brighter
companion color. Each paper color has its own companion citation color; the blue
edition retains the reference cyan-blue (`#00A7E8`).
Every variant uses exactly one paper-optimized Pada horizontal wordmark on the
title card. Both options use transparent backgrounds and graphite lettering:

- `colorlogo` preserves the gradient symbol from the supplied horizontal asset.
- `blacklogo` uses the symbol geometry from the supplied standalone white SVG,
  recolored to graphite for a monochrome treatment on the light title card.

The dark app-icon tile, halo, and excess transparent margins are removed from both.
Their processed SVG masters remain editable in `assets/`, with transparent PNG
copies used by pdfLaTeX.

Compile `main.tex` with pdfLaTeX and BibTeX, or use `latexmk -pdf main.tex`.
